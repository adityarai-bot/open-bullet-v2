﻿namespace OpenBullet2.Core.Models.Proxies
{
    /// <summary>
    /// Options for a <see cref="DatabaseProxyCheckOutput"/>.
    /// </summary>
    public class DatabaseProxyCheckOutputOptions : ProxyCheckOutputOptions
    {

    }
}
