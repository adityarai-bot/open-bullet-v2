﻿using RuriLib.Models.Proxies;

namespace OpenBullet2.Core.Models.Proxies
{
    /// <summary>
    /// Base class for options of an <see cref="IProxyCheckOutput"/>.
    /// </summary>
    public abstract class ProxyCheckOutputOptions
    {

    }
}
