﻿namespace OpenBullet2.Core.Models.Hits
{
    /// <summary>
    /// Options for a <see cref="DatabaseHitOutput"/>.
    /// </summary>
    public class DatabaseHitOutputOptions : HitOutputOptions
    {

    }
}
