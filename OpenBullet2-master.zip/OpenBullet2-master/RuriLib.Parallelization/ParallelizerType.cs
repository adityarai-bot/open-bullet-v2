﻿namespace RuriLib.Parallelization
{
    public enum ParallelizerType
    {
        TaskBased,
        ThreadBased
    }
}
