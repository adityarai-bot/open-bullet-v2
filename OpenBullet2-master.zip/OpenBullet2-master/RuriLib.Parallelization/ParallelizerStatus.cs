﻿namespace RuriLib.Parallelization
{
    public enum ParallelizerStatus
    {
        Idle,
        Starting,
        Running,
        Pausing,
        Paused,
        Stopping,
        Resuming
    }
}
