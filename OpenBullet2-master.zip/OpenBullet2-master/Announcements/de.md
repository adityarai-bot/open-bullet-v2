<p style="font-size: 16px; color: yellowgreen;">INFORMATION</p>

Bitte denke daran, Deine OB2-Instanz auf dem neuesten Stand zu halten. Updates beheben in der Regel Fehler und verbessern die Leistung. Sie sind also eine sehr schöne Sache! Nach der Aktualisierung kannst Du die Liste der Änderungen sehen, indem Du auf das Label klickst, das die aktuelle Version des Programms in der linken unteren Ecke der Seite anzeigt, damit Du genau weisst, was in dieser Version behoben oder hinzugefügt wurde.
