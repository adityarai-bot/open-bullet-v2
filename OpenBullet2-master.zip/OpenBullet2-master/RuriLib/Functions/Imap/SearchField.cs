﻿namespace RuriLib.Functions.Imap
{
    public enum SearchField
    {
        From,
        To,
        Subject,
        Body
    }
}
