﻿namespace RuriLib.Functions.Http
{
    public enum HttpMethod
    {
        GET,
        POST,
        HEAD,
        PUT,
        DELETE,
        PATCH,
        TRACE,
        CONNECT,
        OPTIONS
    }
}
