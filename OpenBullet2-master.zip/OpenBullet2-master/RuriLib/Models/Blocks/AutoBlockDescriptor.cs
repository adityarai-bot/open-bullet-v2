﻿namespace RuriLib.Models.Blocks
{
    public class AutoBlockDescriptor : BlockDescriptor
    {
        public bool Async { get; set; }
    }
}
