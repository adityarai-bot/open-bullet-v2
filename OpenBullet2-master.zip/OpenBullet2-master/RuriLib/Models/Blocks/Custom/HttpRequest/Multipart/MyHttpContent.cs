﻿namespace RuriLib.Models.Blocks.Custom.HttpRequest.Multipart
{
    public abstract class MyHttpContent
    {
        public string Name { get; set; }
        public string ContentType { get; set; }
    }
}
