﻿namespace RuriLib.Logging
{
    public enum LogKind
    {
        Custom,
        Info,
        Success,
        Warning,
        Error
    }
}
